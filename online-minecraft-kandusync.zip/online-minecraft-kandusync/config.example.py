
app = {
    "token":"api token",
    "assign_Group":"something",
    "group_default":"group.default"
}

sql = {
    "host":"0.0.0.0",
    "username":"username",
    "password":"password",
    "database":"database",
}