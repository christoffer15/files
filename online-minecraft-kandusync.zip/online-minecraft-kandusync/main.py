import kandu.api as kandu
import minecraft.api as minecraft
import minecraft.luckperms as luckperms
import config as _cfg
import threading


kandu = kandu.Api(_cfg.app["token"])
minecraft = minecraft.Api()
lp = luckperms.Luckperms()


def run():
    print("Running Sync")
    kuuid = []
    for x in kandu.getall():
        kuuid.append(minecraft.usernametouuid(x))

    lplist = []
    for x in lp.getallusers(_cfg.app["assign_Group"]):
        lplist.append(x[1])

    for i in kuuid:
        if i not in lplist:
            print(f"Added {minecraft.uuidtousername(i)} to group")
            lp.addusertogroup(i, _cfg.app["assign_Group"])
        else:
            print(f"User {minecraft.uuidtousername(i)} already in group")

    for i in lplist:
        if i not in kuuid:
            lp.deleteuserfromgroup(i, _cfg.app["assign_Group"])
            print(f"Removed {minecraft.uuidtousername(i)} from group")


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    threading.Timer(300, run()).start()
