import requests
from requests.structures import CaseInsensitiveDict
import config as _cfg


class Api:

    def uuidtousername(self, uuid):
        r = requests.get(f"https://api.mojang.com/user/profiles/{uuid}/names")
        json = r.json()
        return json[0]["name"]

    def usernametouuid(self, username):
        r = requests.get(f"https://api.mojang.com/users/profiles/minecraft/{username}")
        json = r.json()
        return self.__formatuuid(json["id"])

    def __formatuuid(self,nfuuid):
        return nfuuid[:8]+"-"+nfuuid[8:12]+"-"+nfuuid[12:16]+"-"+nfuuid[16:20]+"-"+nfuuid[20:]


    def __headers(self):
        headers = CaseInsensitiveDict()
        headers["Accept"] = "application/json"
        headers["Authorization"] = "Bearer " + self.token
        return headers


