import mysql.connector
import config as _cfg


class Luckperms:

    def __init__(self):
        self.luckperms = mysql.connector.connect(
            host=_cfg.sql["host"],
            user=_cfg.sql["username"],
            password=_cfg.sql["password"],
            database=_cfg.sql["database"]
        )

    def getallusers(self,groupname):
        dbcur = self.luckperms.cursor()

        dbcur.execute(
            f"select * from s1_luckperms.luckperms_user_permissions where permission = '{groupname}'")

        result = dbcur.fetchall()

        return result

    def deleteuserfromgroup(self, uuid, groupname):
        dbcur = self.luckperms.cursor()

        dbcur.execute(
            f"""
            DELETE FROM s1_luckperms.luckperms_user_permissions
            WHERE permission = '{groupname}'
            AND uuid = '{uuid}';
            """)

        self.luckperms.commit()

        return dbcur.rowcount

    def addusertogroup(self, uuid, groupname):
        dbcur = self.luckperms.cursor()

        dbcur.execute(
            f"""
            insert into luckperms_user_permissions (uuid, permission, `value`, `server`, world, expiry, contexts)
            values ('{uuid}', '{groupname}', '1', 'global', 'global', '0', '')
            """)

        self.luckperms.commit()

        return dbcur.rowcount
