import requests
from requests.structures import CaseInsensitiveDict
import config as _cfg


class Api:
    def __init__(self, token):
        self.token = token

    def get(self, username):
        if username == "":
            print("Uuid empty")
        else:
            return self.__check(username)

    def __headers(self):
        headers = CaseInsensitiveDict()
        headers["Accept"] = "application/json"
        headers["Authorization"] = "Bearer " + self.token
        return headers

    def __check(self, username):
        r = requests.get("https://member.gathering.org/api/check/minecraft/?username=" + username,
                         headers=self.__headers())
        json = r.json()
        if json["result"] == "notfound":
            return False
        else:
            return True

    def getall(self):
        r = requests.get("https://member.gathering.org/api/minecraft/",
                         headers=self.__headers())
        json = r.json()

        return json